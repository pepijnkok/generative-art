<!-- Vergeet je niet de comments uit te zetten voordat je begint met typen? 💬 -->

# Procesverslag

## Over
* **Naam:** Pepijn Kok
* **Klas:** VID-1
* **Minor:** Visual Interface Design
* **Favoriete dier:** Panda's
* **Startniveau:** Blauw

## Concept

`Beschrijf in het algemeen je concept van je project.`

## Features

`Wat zijn de features in het project dat je gemaakt hebt? Waar kan ik op klikken? Waar zit de interactie?`

## Onderzoek & inspiratie
`Schrijf wat over je onderzoek en je inspiratie voor het project. Hoe kwam je concept tot stand?`

## Voortang

`Schrijf hier een klein logboekje met je voortgang per week.`

### Week-1
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`

### Week-2
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`

### Week-3
`Wat heb je gedaan? Wat ging goed? Wat kon beter?`


## Bronnenlijst

* Bron 1: https://www.youtube.com/watch?v=me04ZrTJqWA
* `Link naar bron 2`
* `Link naar bron 3`
